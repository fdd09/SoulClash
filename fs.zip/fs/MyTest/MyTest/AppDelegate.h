//
//  AppDelegate.h
//  MyTest
//
//  Created by fengdongwang on 2020/9/20.
//  Copyright © 2020 fdd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Flutter/Flutter.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic,strong) FlutterEngine *flutterEngine;


@end

