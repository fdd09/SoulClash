//
//  ViewController.m
//  MyTest
//
//  Created by fengdongwang on 2020/9/20.
//  Copyright © 2020 fdd. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import <Flutter/Flutter.h>

@interface ViewController () <FlutterStreamHandler>

@property(nonatomic) FlutterBasicMessageChannel *basicMethodChannel;
@property(nonatomic) FlutterMethodChannel *methodChannel;
@property(nonatomic) FlutterEventChannel* eventChannle;
@property(nonatomic) FlutterEngine *flutterEngine;
@property(nonatomic) FlutterViewController *flutterViewController;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
       [button addTarget:self
                  action:@selector(showFlutter)
        forControlEvents:UIControlEventTouchUpInside];
       [button setTitle:@"Show Flutter!" forState:UIControlStateNormal];
       button.backgroundColor = UIColor.blueColor;
       button.frame = CGRectMake(80.0, 210.0, 160.0, 40.0);
       [self.view addSubview:button];
    
    
}

- (void)showFlutter {
    _flutterEngine =
        ((AppDelegate *)UIApplication.sharedApplication.delegate).flutterEngine;
    _flutterViewController =
        [[FlutterViewController alloc] initWithEngine:_flutterEngine nibName:nil bundle:nil];
    _flutterViewController.modalPresentationStyle = UIModalPresentationFullScreen;
    _flutterViewController.view.frame = CGRectMake(0, 300, 375, 500);
    [self addChildViewController:_flutterViewController];
    [_flutterViewController didMoveToParentViewController:self];
    [self.view addSubview:_flutterViewController.view];
    
    [self registerChannel];
}

- (void)registerChannel {
    
    _basicMethodChannel = [FlutterBasicMessageChannel messageChannelWithName:@"BasicMessageChannel" binaryMessenger:[_flutterViewController binaryMessenger]];
       // 注册方法等待flutter页面调用
       [_basicMethodChannel setMessageHandler:^(id  _Nullable message, FlutterReply  _Nonnull callback) {
           NSString *method=message[@"method"];
           if ([method isEqualToString:@"test"]) {
               //调用原生自定义方法
               //[weakSelf testMethod];

               //返回flutter数据
               NSMutableDictionary *dic = [NSMutableDictionary dictionary];
               [dic setObject:@"basicMethodChannel 原生返回flutter的数据" forKey:@"message"];
               [dic setObject: [NSNumber numberWithInt:200] forKey:@"code"];
               [dic setObject: @"内容" forKey:@"context"];
               callback(dic);
           }
       }];
    
    
    _methodChannel = [FlutterMethodChannel methodChannelWithName:@"MethodChannel" binaryMessenger:[_flutterEngine binaryMessenger]];

       [_methodChannel setMethodCallHandler:^(FlutterMethodCall* call, FlutterResult result) {
           NSLog(@"%@", call.method);
           NSLog(@"%@", call.arguments);
           if ([call.method isEqualToString:@"methodChannelTest"]) {
               //[weakSelf testMethod];

               //返回flutter数据
               NSMutableDictionary *dic = [NSMutableDictionary dictionary];
               [dic setObject:@"methodChannel 原生返回flutter的数据" forKey:@"message"];
               [dic setObject: [NSNumber numberWithInt:200] forKey:@"code"];
               [dic setObject: @"内容" forKey:@"context"];
               result(dic);
           }

       }];
    
    
   _eventChannle = [FlutterEventChannel eventChannelWithName:@"EventChannel" binaryMessenger:[_flutterEngine binaryMessenger]];
      [_eventChannle setStreamHandler:self];
    
}

- (FlutterError* _Nullable)onListenWithArguments:(id _Nullable)arguments
                                       eventSink:(FlutterEventSink)events {
    NSLog(@"=====%@", arguments);
    events(@{@"1": @"1", @"2": @"2"});
    return nil;
}

- (FlutterError* _Nullable)onCancelWithArguments:(id _Nullable)arguments {
    return nil;
}

@end
