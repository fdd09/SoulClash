//
//  SceneDelegate.h
//  MyTest
//
//  Created by fengdongwang on 2020/9/20.
//  Copyright © 2020 fdd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

