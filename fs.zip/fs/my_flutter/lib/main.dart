import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

//BasicMessageChannel
  static const basicMessageChannel =
      const BasicMessageChannel('BasicMessageChannel', StandardMessageCodec());

//MethodChannel
  static const methodChannel = const MethodChannel('MethodChannel');

//EventChannel
  static const eventChannel = const EventChannel('EventChannel');

  @override
  void initState() {
    super.initState();
  }

  /*
 * BasicMessageChannel
 * 实现Flutter 调用Android iOS原生方法并回调
 * arguments 发送给原生的参数 ,自定义基本数据格式{"method": "test", "content": "flutter 中的数据", "code": 100}
 * return数据 原生发给Flutter的参数,自定义基本数据格式{"code":100,"message":"消息","content":内容}
 */
  Future<Map> toolsBasicChannelMethodWithParams(Map arguments) async {
    var result;
    try {
      result = await basicMessageChannel.send(arguments);
    } catch (e) {
      result = {'Failed': e.message};
      print(e);
    }
    return result;
  }

//BasicMessageChannel 调用原生方法并回调 按钮点击触发事件
  void basicChannelMethod() {
    Map params = {"method": "test", "context": "testValue", "code": 200};
    toolsBasicChannelMethodWithParams(params).then((result) {
      //result 原生回调结果
      // _result = result.toString();
      print(result);
    });
    setState(() {});
  }

/*
 * MethodChannel
 * 在方法通道上调用方法invokeMethod
 * methodName 方法名称
 * params 发送给原生的参数，自定义基本数据格式{"code":100,"message":"消息","content":内容}
 * return数据 原生发给Flutter的参数,自定义基本数据格式{"code":100,"message":"消息","content":内容}
 */
  Future<Map> toolsMethodChannelMethodWithParams(String methodName,
      [Map params]) async {
    var res;
    try {
      res = await methodChannel.invokeMethod('$methodName', params);
    } catch (e) {
      res = {'Failed': e.message};
    }
    return res;
  }

  //MethodChannel 调用原生方法并回调 按钮点击触发事件
  void methodChannelMethod() {
    //调用ChannelTools中的方法 参数一方法名 参数二、Map类型键值对参数
    toolsMethodChannelMethodWithParams('methodChannelTest').then((result) {
      //result 原生回调结果
      // _result = result.toString();
      print(result);
    });
    setState(() {});
  }

/*
 * EventChannel
 * return数据 原生发给Flutter的参数,自定义基本数据格式{"code":100,"message":"消息","content":内容}
 * result listen监听结果
 */
  void toolsEventChannelMethod(Function result) {
    //不指定返回值类型，函数返回值默认为Object
    eventChannel.receiveBroadcastStream({"flutter": "1"}).listen(result);
  }
  //EventChannel 原生数据传递 按钮点击触发事件

  void eventChannelMethod() {
    //data 原生
    toolsEventChannelMethod((data) {
      //  _result = data;
      print(data);
    });
    setState(() {});
  }

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  void _dismiss() {
    print("消失");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Container(
        color: Colors.red,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              FloatingActionButton(
                onPressed: () {
                  basicChannelMethod();
                },
                child: Text("1"),
              ),
              FloatingActionButton(
                isExtended: true,
                onPressed: () {
                  methodChannelMethod();
                },
                child: Text("2"),
              ),
              FloatingActionButton(
                onPressed: () {
                  eventChannelMethod();
                },
                child: Text("3"),
              ),
              FloatingActionButton(
                onPressed: () {},
                child: Text("返回"),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment111',
        child: Icon(Icons.star),
      ),
    );
  }
}
